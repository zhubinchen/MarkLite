## FQA

### How to create a file
* The first way, click the "+" button at the top right of navigation bar, select the directory which you want to create in, and then enter the file name. 
**Don't enter special characters (such as `/*.` like.)**

* The second way, click the "Edit" button at at the top right of navigation bar, then click the "+" button at the right of the cell which want to create file in, and then select a file type and input the input file name

### How to export files to other app
Click the "more" button on the right side of the target file, select "export".

if the destination app wasn't appear in the application list, please click "more", turn on the switch of the app.

> Tip: In the preview interface,you can export the web page or PDF rendered from the markdown

### How to import a file

* You can use AirDrop to send the file to your iPhone, then open it by MarkLite;
* Second way, copy the file to the "MarkLite" directly in the iCloud Device on the Mac.The file will appear in the file list in MarkLite app.

### Where is the file saved in iCloud

You can open your "Device iCloud" app, there is a directory named "MarkLite", the files in that directory can be shared between your different devices. 

### why some syntax can be rendered correctly

Please check if your grammar is correctly, some syntax can be highlighted does not mean it is a correctly
> Such as, `#title` is wrong, it should be `# title`