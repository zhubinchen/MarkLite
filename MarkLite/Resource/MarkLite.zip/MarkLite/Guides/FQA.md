## FQA

### How to create a file
* Click the "+" button at the top right of navigation bar, select the directory which you want to create in, and then enter the file name. 
**Don't enter special characters (such as `/*.` like.)**

### How to export files to other app
Swpie the cell,and click the export button.

if the destination app wasn't appear in the application list, please click "more", turn on the switch of the app.

> Tip: In the preview,you can export the web page or PDF rendered from the markdown

### How to import a file

* You can use AirDrop to send the file to your iPhone, then open it by MarkLite;
* Second way, copy the file to the "MarkLite" directly in the iCloud Device on the Mac.The file will appear in the file list in MarkLite app.

### Where is the file saved in iCloud

You can open your "Device iCloud" app, there is a directory named "MarkLite", the files in that directory can be shared between your different devices. 

### why some syntax cannot be rendered correctly

Please check if your grammar is correctly, some syntax can be highlighted does not mean it is a correctly
> Such as, `#title` is wrong, it should be `# title`

**If you have any other questions,just feedback**