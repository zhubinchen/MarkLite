### Switch to iCloud
1. Clicking the title of the home page, the iCloud option will appear
2. If you can not access iCloud, go to the system settings, check if your iCloud account is logined on your device

### Create a note or folder
1. Pull down the file list to create a note
2. Click the edit button at topRight

### Rename file
1. Slide the file list cell left
2. Click the file name at top bar

### Save file
1. MarkLite will save your file after edited automatically

### iCloud issues
1. File may not be synchronized realtime
2. If a file write to iCloud successed, you can find it in your iCloud drive

### Other quetions

Email me: [cheng4741@gmail.com](mailto:cheng4741@gmail.com)