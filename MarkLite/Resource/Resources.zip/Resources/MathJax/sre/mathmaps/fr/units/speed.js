[{"locale":"fr"},{"key":"mph","mappings":{"default":{"default":"miles par heure","singular":"mile par heure","dual":""}},"names":["mph"]}]
