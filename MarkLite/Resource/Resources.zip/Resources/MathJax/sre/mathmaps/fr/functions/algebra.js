[{"locale":"fr"},{"category":"Algebra","mappings":{"default":{"default":"déterminant"}},"key":"det","names":["det"]}]
